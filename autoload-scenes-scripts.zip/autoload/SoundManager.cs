using Godot;
using System;
using System.Linq;
using static Singletons;

public class SoundManager : Node
{
    public Timer GCTimer;
    public Node2D Songs;
    public Node2D Sounds;

    public override void _Ready()
    {
        Sounds = GetNode<Node2D>("Sounds");
        Songs = GetNode<Node2D>("Songs");
        GCTimer = GetNode<Timer>("GCTimer");
        GCTimer.Connect("timeout", this, "_GC");
    }

    public AudioStreamPlayer Load(string sound = "", in string id = "", in float gain = 0f, byte[] key = null, in string bus = "Sounds")
    {
        if (key == null) key = new byte[]{};
        sound = "sounds/" + sound;
        AudioStreamOGGVorbis target = Assets.GetAudio(sound, key);
        // if (target == null) target = Assets.GetAudio(sound, key);
        if (target == null)
        {
            GD.Print("ERROR: Could not play sound: ", sound);
            return null;
        }
        target.Loop = false;

        AudioStreamPlayer snd = new AudioStreamPlayer();
        snd.Bus = bus;
        snd.Stream = target;
        snd.VolumeDb = gain;
        snd.Name = ";" + id;
        Sounds.AddChild(snd);
        return snd;
    }

    public AudioStreamPlayer Play(in string sound = "", in string id = "", in float gain = 0f, byte[] key = null, in string bus = "Sounds")
    {
        if (key == null) key = new byte[]{};
        if (Load(sound, id, gain, key, bus) is AudioStreamPlayer snd)
        {
            snd.Play();
            return snd;
        }
        return null;
    }

    public AudioStreamPlayer LoadMusic(string song = "", in string id = "", in float gain = 0f, in bool loop = true, byte[] key = null, in string bus = "Music")
    {
        if (key == null) key = new byte[]{};
        song = "songs/" + song;
        AudioStreamOGGVorbis target = Assets.GetAudio(song, key);
        if (target == null)
        {
            GD.Print("ERROR: Could not play song: ", song);
            return null;
        }
        target.Loop = loop;

        AudioStreamPlayer mus = new AudioStreamPlayer();
        mus.Bus = bus;
        mus.Stream = target;
        mus.VolumeDb = gain;
        mus.Name = ";" + id;
        Songs.AddChild(mus);
        return mus;
    }

    public AudioStreamPlayer PlayMusic(in string song = "", in string id = "", in float gain = 0f, in bool loop = true, byte[] key = null, in string bus = "Music")
    {
        if (key == null) key = new byte[]{};
        if (LoadMusic(song, id, gain, loop, key, bus) is AudioStreamPlayer mus)
        {
            mus.Play();
            return mus;
        }
        return null;
    }

    public void Stop(in AudioStreamOGGVorbis stream)
    {
        foreach (AudioStreamPlayer i in Sounds.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(i).GetRef() != null)
            {
                if (i.Stream != null)
                {
                    if (i.Stream == stream) i.Stop();
                }
            }
        }
    }

    public void Stop(in string id = "")
    {
        AudioStreamPlayer i = Find(id);
        if (i == null) return;
        i.Stop();
    }

    public void Kill(in AudioStreamOGGVorbis stream)
    {
        foreach (AudioStreamPlayer i in Sounds.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(i).GetRef() != null)
            {
                if (i.Stream != null)
                {
                    if (i.Stream == stream)
                    {
                        Sounds.RemoveChild(i);
                        i.QueueFree();
                    }
                }
            }
        }
    }

    public void Kill(in string id = "")
    {
        AudioStreamPlayer i = Find(id);
        if (i == null) return;
        Sounds.RemoveChild(i);
        i.QueueFree();
    }

    public void StopMusic(in AudioStreamOGGVorbis stream)
    {
        foreach (AudioStreamPlayer i in Songs.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(i).GetRef() != null)
            {
                if (i.Stream == stream) i.Stop();
            }
        }
    }

    public void StopMusic(in string id = "")
    {
        AudioStreamPlayer i = FindMusic(id);
        if (i == null) return;
        i.Stop();
    }

    public void KillMusic(in AudioStreamOGGVorbis stream)
    {
        foreach (AudioStreamPlayer i in Songs.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(i).GetRef() != null)
            {
                if (i.Stream == stream)
                {
                    Songs.RemoveChild(i);
                    i.QueueFree();
                }
            }
        }
    }

    public void KillMusic(in string id = "")
    {
        AudioStreamPlayer i = FindMusic(id);
        if (i == null) return;
        Songs.RemoveChild(i);
        i.QueueFree();
    }

    public void StopAll()
    {
        foreach (AudioStreamPlayer sound in Sounds.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(sound).GetRef() != null)
            {
                sound.Stop();
            }
        }

        foreach (AudioStreamPlayer song in Songs.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(song).GetRef() != null)
            {
                song.Stop();
            }
        }
    }

    public void KillAll()
    {
        foreach (AudioStreamPlayer sound in Sounds.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(sound).GetRef() != null)
            {
                Sounds.RemoveChild(sound);
                sound.QueueFree();
            }
        }

        foreach (AudioStreamPlayer song in Songs.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(song).GetRef() != null)
            {
                Songs.RemoveChild(song);
                song.QueueFree();
            }
        }
    }

    public void _GC()
    {
        foreach (AudioStreamPlayer i in Sounds.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(i).GetRef() != null)
            {
                if (!i.Playing)
                {
                    Sounds.RemoveChild(i);
                    i.QueueFree();
                }
            }
        }
    }

    public AudioStreamPlayer Find(in string id = "")
    {
        foreach (AudioStreamPlayer i in Sounds.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(i).GetRef() != null)
            {
                if (i.Name == ";" + id) return i;
            }
        }
        return null;
    }

    public AudioStreamPlayer FindMusic(in string id = "")
    {
        foreach (AudioStreamPlayer i in Songs.GetChildren().OfType<AudioStreamPlayer>())
        {
            if (WeakRef(i).GetRef() != null)
            {
                if (i.Name == ";" + id) return i;
            }
        }
        return null;
    }
}
