using Godot;
using Godot.Collections;
using Array = Godot.Collections.Array;
using System;
using static Singletons;

public class AssetManager : Node
{
    public Dictionary<string, object> assets = new Dictionary<string, object>();
    public Array<string> manifest = new Array<string>();
    
    public string assetPath = "res://assets" + "/";

    public void ErrNotFound()
    {
        GD.Print("ERR: Asset Not Found!");
    }

    public Array Fetch(string path)
    {
        // path = path.ToLower();
        for (int i = 0; i < manifest.Count; i++)
        {
            string curFilePath = manifest[i];
            string absPath = assetPath + curFilePath;
            if (curFilePath.Find(path) != -1)
            {
                if (absPath.EndsWith(".sec"))
                {
                    File f = new File();
                    if (f.Open(absPath, File.ModeFlags.Read) == Error.Ok)
                    {
                        Array secArr = new Array(){ f.GetBuffer((long)f.GetLen()), absPath };
                        f.Close();
                        return secArr;
                    }
                    else
                    {
                        
                        ErrNotFound();
                    }
                }
                else if (!assets.ContainsKey(curFilePath))
                {
                    assets.Add(curFilePath, ResourceLoader.Load(absPath));
                }
                if (assets[curFilePath] == null)
                {
                    File f = new File();
                    if (f.Open(absPath, File.ModeFlags.Read) == Error.Ok)
                    {
                        assets[curFilePath] = f.GetBuffer((long)f.GetLen());
                        f.Close();
                    }
                }
                return new Array(){ assets[curFilePath], absPath };
            }
        }
        return new Array(){ null, "" };
    }

    public string Extify(in string a = "", in string b = "")
    {
        return b + "/" + a + "." + b;
    }

    public byte[] GetBytes(string path = "", byte[] key = null)
    {
        if (key == null) key = new byte[]{};
        // path = path.ToLower();
        for (int i = 0; i < manifest.Count; i++)
        {
            string curFilePath = manifest[i];
            if (curFilePath.Find(path) != -1)
            {
                string absPath = assetPath + curFilePath;
                File f = new File();
                if (f.Open(absPath, File.ModeFlags.Read) == Error.Ok)
                {
                    byte[] byteArray = f.GetBuffer((long)f.GetLen());
                    f.Close();
                    if (absPath.EndsWith(".sec")) byteArray = AES.Decrypt(key, byteArray);
                    return byteArray;
                }
                else
                {
                    ErrNotFound();
                }
            }
        }
        return new byte[]{};
    }

    public string GetText(in string path = "", in bool utf8 = false, in bool lf = false)
    {
        byte[] byteArray = GetBytes("data/" + path + ".txt");
        string txtData = byteArray.GetStringFromASCII();
        if (utf8) txtData = byteArray.GetStringFromUTF8();
        if (lf) return String.Join("", txtData.Split("\r"));
        return txtData;
    }

    public string GetDat(in string path = "", in bool utf8 = false, in bool lf = false)
    {
        byte[] byteArray = GetBytes("data/" + path + ".dat");
        string txtData = byteArray.GetStringFromASCII();
        if (utf8) txtData = byteArray.GetStringFromUTF8();
        if (lf) return String.Join("", txtData.Split("\r"));
        return txtData;
    }

    public string GetSecText(in string path = "", in bool utf8 = false, in bool lf = false, byte[] key = null)
    {
        if (key == null) key = new byte[]{};
        byte[] byteArray = GetBytes("sec/data/" + path + ".sec", key);
        string txtData = byteArray.GetStringFromASCII();
        if (utf8) txtData = byteArray.GetStringFromUTF8();
        if (lf) return String.Join("", txtData.Split("\r"));
        return txtData;
    }

    public SpriteFrames GetSpriteFrames(in string path = "")
    {
        Array res = Fetch(Extify(path, "res"));
        if (res[0] == null || res.Count != 2) return null;
        string p = "";
        if (res[1] is string r1) p += r1;
        if (p.Length < 4) return null;
        string pExt = p.Substring(p.Length - 4);
        if (pExt != ".res") return null;
        return (SpriteFrames)res[0];
    }

    public AudioStreamOGGVorbis GetAudio(in string path = "", byte[] key = null)
    {
        if (key == null) key = new byte[]{};
        Array res = Fetch(Extify(path, "ogg"));
        if (res[0] == null) res = Fetch(Extify("ogg/" + path, "sec"));
        if (res[0] == null || res.Count != 2) return null;
        string p = "";
        if (res[1] is string r1) p += r1;
        if (p.Length < 4) return null;
        string pExt = p.Substring(p.Length - 4);
        switch (pExt)
        {
            case ".sec":
                byte[] resBytes = new byte[]{};
                if (res[0] is byte[] r0s) resBytes = r0s;
                byte[] oggArr = AES.Decrypt(key, resBytes);
                AudioStreamOGGVorbis oggS = new AudioStreamOGGVorbis();
                oggS.Data = oggArr;
                return oggS;
            case ".ogg":
                if (res[0] is byte[] r0)
                {
                    AudioStreamOGGVorbis ogg = new AudioStreamOGGVorbis();
                    ogg.Data = r0;
                    return ogg;
                }
                return (AudioStreamOGGVorbis)res[0];
            default:
                return null;
        }
    }

    public Image GetPng(in string path = "", byte[] key = null)
    {
        if (key == null) key = new byte[]{};
        Array res = Fetch(Extify(path, "png"));
        if (res[0] == null) res = Fetch(Extify("png/" + path, "sec"));
        if (res[0] == null || res.Count != 2) return null;
        string p = "";
        if (res[1] is string r1) p += r1;
        if (p.Length < 4) return null;
        string pExt = p.Substring(p.Length - 4);
        switch (pExt)
        {
            case ".sec":
                byte[] resBytes = new byte[]{};
                if (res[0] is byte[] r0) resBytes = r0;
                byte[] imgArr = AES.Decrypt(key, resBytes);
                Image img = new Image();
                if (img.LoadPngFromBuffer(imgArr) != Error.Ok) return null;
                return img;
            case ".png":
                return (Image)res[0];
            default:
                return null;
        }
    }

    public Resource GetScene(in string path = "")
    {
        return ResourceLoader.Load("res://scenes/" + path + ".tscn");
    }

    public Resource GetStage(in string path = "")
    {
        return GetScene("stages/" + path);
    }

    public Array<string> ProcessManifest(in string folder = "")
    {
        Array<string> files = new Array<string>();
        Directory dir = new Directory();
        if (dir.Open(folder) == Error.Ok)
        {
            if (dir.ListDirBegin(true, false) == Error.Ok)
            {
                string filePath = dir.GetNext();
                while (filePath != "")
                {
                    if (dir.CurrentIsDir())
                    {
                        files += ProcessManifest(folder + filePath + "/");
                    }
                    else
                    {
                        files.Add(folder + filePath);
                    }
                    filePath = dir.GetNext();
                }
            }
        }
        return files;
    }

    public void UpdateManifest()
    {
        foreach (string file in ProcessManifest(assetPath))
        {
            string fileName = file.Substring(assetPath.Length); //.ToLower();
            if (!manifest.Contains(fileName)) manifest.Add(fileName);
        }
    }

    public override void _Ready()
    {
        UpdateManifest();
    }
}
