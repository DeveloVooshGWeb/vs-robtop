using Godot;
using Array = Godot.Collections.Array;
using System.Linq;
using static Singletons;

public class GEVTParser
{
    public string defaultDelimiter = " ";
    public string[][] delimiters = { new string[]{ "\"", "\"" }, new string[]{ "[", "]" }, new string[]{ "{", "}" } };

    public EventData[] Parse(string code)
    {
        EventData[] events = new EventData[]{};
        string[] lines = string.Join("", code.Split("\r")).Split("\n");
        foreach (string l in lines)
        {
            string line = l.StripEdges();
            if (line != "" && !line.BeginsWith("#"))
            {
                line += " ";
                string function = "";
                Array args = new Array();
                string text = "";
                DelimiterProperties delimiterProperties = new DelimiterProperties();
                for (int i = 0; i < line.Length; i++)
                {
                    char character = line[i];
                    text += character;
                    foreach (string[] delimiter in delimiters)
                    {
                        if (delimiter.Contains<string>(delimiterProperties.delimiter) || delimiterProperties.delimiter == "")
                        {
                            int curFlag = delimiterProperties.flag;
                            if (curFlag < 1) curFlag = 1;
                            switch (curFlag)
                            {
                                case 1:
                                    ref string curDelim0 = ref delimiter[0];
                                    if (text.EndsWith(" " + curDelim0))
                                    {
                                        text = "";
                                        delimiterProperties.delimiter = curDelim0;
                                        delimiterProperties.flag = 2;
                                    }
                                    break;
                                case 2:
                                    ref string curDelim1 = ref delimiter[1];
                                    if (text.EndsWith(curDelim1 + " "))
                                    {
                                        text = text.StripEdges().Substr(0, text.Length - curDelim1.Length);
                                        args.Add(GD.Str2Var(delimiter[0] + text + curDelim1));
                                        text = "";
                                        delimiterProperties.delimiter = "";
                                        delimiterProperties.flag = 1;
                                    }
                                    break;
                            }
                        }
                    }
                    if (delimiterProperties.delimiter == "" && text.EndsWith(" "))
                    {
                        text = text.StripEdges();
                        if (text != "")
                        {
                            if (args.Count <= 0) function = text;
                            args.Add(GD.Str2Var(text));
                            text = "";
                        }
                    }
                }
                if (text != "")
                {
                    if (args.Count <= 0) function = text;
                    args.Add(text);
                    text = "";
                }
                args.RemoveAt(0);
                Utils.Push(ref events, new EventData(function, args));
            }
        }
        return events;
    }
}
