using Godot;
using Godot.Collections;
using System;

public class DataHandler : Node
{
    public bool disableInput = false;
   
    public float speedMultiplier = 0.45f;

    public float rowCap = 8f;
    public float maxRowCap = 128f;
    public float maxNoteLength = 65.535f;
    public float maxScrollSpeed = 65.535f;

    public float vocalResetThres = 0.015f;

    public int safeFrames = 10;
    public float safeZoneOffset;
    public float[] sigobashOffsets;
    public float[] gradeAcc = { 100f, 98f, 90f, 80f, 75f, 0f };

    public Vector2 vec2cen = new Vector2(960, 540);

    /*
    public Dictionary<string, object> defaultSectionProperties = new Dictionary<string, object>(){
        { "MustHitSection", true },
        { "Notes", new Dictionary<string, object>() }
    };

    public Dictionary<string, object> defaultChartProperties = new Dictionary<string, object>(){
        { "Bpm", (ushort)130 },
        { "ScrollSpeed", 1f },
        { "Song", "" }
    };

    public Dictionary<string, object> defaultProperties = new Dictionary<string, object>(){
        { "Alt", false },
        { "IsStrum", true },
        { "Col", (sbyte)-1 },
        { "Row", (sbyte)-1 },
        { "NoteType", (byte)0 },
        { "NoteId", (byte)2 },
        { "NoteOffset", Vector2.Zero },
        { "NoteLength", 0f },
        { "Evt", "" }
    };

    public Dictionary<string, object> defaultMiscProperties = new Dictionary<string, object>(){
        { "TargetPos", Vector2.Zero },
        { "HoldUpdate", false },
        { "Steps", 0f },
        { "Time", 0m },
        { "Speed", 1f },
        { "Data", new Dictionary<string, object>() }
    };
    */

    public string[] noteVariants = {
        "Default",
        "BadNoteDragon",
        "BadNoteFuzz",
        "BadNoteSkull",
        "BadNoteSpike",
        "CurrencyNoteCoin",
        "GoodNoteFlask",
        "GoodNoteHeart",
        "GoodNoteKey"
    };

    public Dictionary<int, string> noteTypeLabels = new Dictionary<int, string>(){
        { 0, "Note" },
        { 1, "Bad" },
        { 2, "Bad" },
        { 3, "Bad" },
        { 4, "Bad" },
        { 5, "Coin" },
        { 6, "Good" },
        { 7, "Good" },
        { 8, "Good" }
    };

    public Vector2[] noteVariantOffsets = {
        Vector2.Zero,
        new Vector2(0, 86),
        new Vector2(0, 86),
        new Vector2(0, 86),
        new Vector2(0, 86),
        new Vector2(0, 86),
        new Vector2(0, 86),
        new Vector2(0, 86),
        new Vector2(0, 86)
    };

    public Vector2[] hardcodedNoteScales = {
        Vector2.One,
        Vector2.One * 1.25f,
        Vector2.One * 1.25f,
        Vector2.One * 1.25f,
        Vector2.One * 1.25f,
        Vector2.One * 1.25f,
        Vector2.One * 1.25f,
        Vector2.One * 1.25f,
        Vector2.One * 1.25f
    };

    public int NoteSize = 164;

    public Dictionary<string, string[]> icons = new Dictionary<string, string[]>(){
        { "enough", new string[]{ "robtop", "bf" } }
    };

    public string Song = "";
    
    public Dictionary<string, object> loadData = new Dictionary<string, object>(){
        { "Difficulty", 1 },
        { "Queue", new string[]{ "warning" } },
        { "Story", false }
    };

    // Platformer shiz time
    public Dictionary<string, object> platData = new Dictionary<string, object>(){
        { "Theme", Color.Color8(70, 60, 242, 255) }
    };

    // Packs
    public PackData[] packData = {
        new PackData("GWeb", Color.Color8(0, 255, 125, 255), 8, 8),
        new PackData("Valen", Color.Color8(0, 210, 255, 255), 4, 2),
        new PackData("Gamemaster", Color.Color8(200, 225, 125, 255), 6, 4)
    };

    public Dictionary<string, object> selectionData = new Dictionary<string, object>()
    {
        { "Id", "GWeb" },
        { "Songs", new string[]{
            "Rush",
            "Vault",
            "Chip",
            "Harm",
            "Warning",
            "Enough",
            "Loop",
            "Out"
        }}
    };

    public int goState = 1;

    public string curPath = "";

    public override void _Ready()
    {
        safeZoneOffset = safeFrames / 60f;
        sigobashOffsets = new float[]{ safeZoneOffset * 0.85f, safeZoneOffset * 0.5f, safeZoneOffset * 0.35f, 0f };
        System.Collections.Generic.List<string> curPathArr = new System.Collections.Generic.List<string>(OS.GetExecutablePath().Split("/"));
        curPathArr.RemoveAt(curPathArr.Count - 1);
        curPath = String.Join("/", curPathArr.ToArray()) + "/";
    }

    public Dictionary<string, object> ColorHSV(float h = 360f, float s = 0f, float v = 100f, float a = 100f)
    {
        // stol-
	    // i mean borrowed and modified from https://www.reddit.com/r/godot/comments/ajll6t/create_color_from_hsv_values/
	
	    // original comments:
	    // based on code at
        // http://stackoverflow.com/questions/51203917/math-behind-hsv-to-rgb-conversion-of-colors
    
        if (h > 360f) h = 360f;
        if (h < -360f) h = -360f;
        if (s > 100f) s = 100f;
        if (v > 100f) v = 100f;
        if (s < 0f) s = 0f;
        if (v < 0f) v = 0f;
        if (a > 1f) a = 1f;
        if (a < 0f) a = 0f;

        float[] hsv = { h, s, v };
        
        h /= 360f;
        s /= 100f;
        v /= 100f;

        float r = 0f;
        float g = 0f;
        float b = 0f;

        float i = Mathf.Floor(h * 6f);
        float f = h * 6f - i;
        float p = v * (1f - s);
        float q = v * (1f - f * s);
        float t = v * (1f - (1f - f) * s);

        switch ((int)i)
        {
            case 0:
                r = v;
                g = t;
                b = p;
                break;
            case 1:
                r = q;
                g = v;
                b = p;
                break;
            case 2:
                r = p;
                g = v;
                b = t;
                break;
            case 3:
                r = p;
                g = q;
                b = v;
                break;
            case 4:
                r = t;
                g = p;
                b = v;
                break;
            case 5:
                r = v;
                g = p;
                b = q;
                break;
        }

        return new Dictionary<string, object>()
        {
            { "Rgb", new Color(r, g, b, a) },
            { "Hsv", hsv }
        };
    }
}
