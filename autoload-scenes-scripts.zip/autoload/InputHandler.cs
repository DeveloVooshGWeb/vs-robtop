using Godot;
using Godot.Collections;
using static Singletons;

public class InputHandler : Node
{
    [Signal] public delegate void justPressed(string Key);
    [Signal] public delegate void pressed(string Key, float delta);
    [Signal] public delegate void justReleased(string Key);

    [Signal] public delegate void mouseDoubleClick(int Idx, Vector2 Pos); 
    [Signal] public delegate void mouseDown(int Idx, Vector2 Pos);
    [Signal] public delegate void mouseUp(int Idx, Vector2 Pos);
    [Signal] public delegate void mouseDrag(int Idx, Vector2 Pos);
    [Signal] public delegate void mouseScroll(int Idx, Vector2 Pos);
    [Signal] public delegate void mouseMove(Vector2 Pos);

    [Signal] public delegate void globalMouseDown(int Idx, Vector2 Pos);
    [Signal] public delegate void globalMouseUp(int Idx, Vector2 Pos);
    [Signal] public delegate void globalMouseMove(Vector2 Pos);

    public Array<string> Keys = new Array<string>();
    public bool[] Held = { false, false, false };

    public override void _Process(float delta)
    {
        if (!Data.disableInput) foreach (string Key in Keys) EmitSignal("pressed", Key, delta);
    }

    public override void _Input(InputEvent @event)
    {
        if (!Data.disableInput && @event is InputEventKey IEK)
        {
            string Key = OS.GetScancodeString(IEK.GetScancodeWithModifiers());
            if (IEK.Pressed)
            {
                if (!Keys.Contains(Key))
                {
                    EmitSignal("justPressed", Key);
                    Keys.Add(Key);
                }
                return;
            }
            EmitSignal("justReleased", Key);
            if (Keys.Contains(Key)) Keys.Remove(Key);
        }
        else if (@event is InputEventMouseButton IEMB)
        {
            int Idx = IEMB.ButtonIndex - 1;
            Vector2 Pos = IEMB.Position;
            if (0 <= Idx && Idx < 3)
            {
                Held[Idx] = IEMB.Pressed;
                Idx++;
                switch (IEMB.Pressed)
                {
                    case true:
                        if (!Data.disableInput)
                        {
                            if (IEMB.Doubleclick) EmitSignal("mouseDoubleClick", Idx, Pos);
                            EmitSignal("mouseDown", Idx, Pos);
                            EmitSignal("mouseDrag", Idx, Pos);
                        }
                        EmitSignal("globalMouseDown", Idx, Pos);
                        break;
                    case false:
                        if (!Data.disableInput) EmitSignal("mouseUp", Idx, Pos);
                        EmitSignal("globalMouseUp", Idx, Pos);
                        break;
                }
            }
            else if (!Data.disableInput && Idx < 5)
            {
                Idx -= 3;
                EmitSignal("mouseScroll", Idx, Pos);
            }
        }
        else if (@event is InputEventMouseMotion IEMM)
        {
            if (!Data.disableInput)
            {
                EmitSignal("mouseMove", IEMM.Position);
                for (int i = 0; i < Held.Length; i++)
                {
                    if (Held[i]) EmitSignal("mouseDrag", i + 1, IEMM.Position);
                }
            }
            EmitSignal("globalMouseMove", IEMM.Position);
        }
    }
}
