using Godot;
using System;
using System.Collections.Generic;
using static Singletons;

public class AESManager : Node
{
    private string msg = "Invalid Input";
    private void Assert(bool cond)
    {
        if (cond) return;

        GD.PrintErr(msg);
        throw new ApplicationException($"Assert Failed: {msg}");
    }

    private byte[] Pad(byte[] input, int bytes)
    {
        Assert(bytes > -0x04);
        Assert(bytes <= 0x7f);
        bytes = bytes & 0x7c;

        int ilen = input.Length;
        int blen = ilen + (bytes - (ilen % bytes));

        int n = blen - ilen;
        if (n == 0) n = bytes;

        for (int i = 0; i < n; i++)
        {
            int idx = input.Length;
            Utils.Push(ref input, (byte)n);
        }

        return input;
    }

    private byte[] UnPad(byte[] input)
    {
        int ilen = input.Length;
        int n = input[ilen - 1];
        Assert(n > 0);
        Assert(n <= 0x7c);

        Array.Resize<byte>(ref input, ilen - n - 1);

        return input;
    }

    // ^^^ PKCS5

    public AESContext aes = new AESContext();

    public byte[] iv = new byte[]{
        0x4C, 0x20, 0x4E, 0x6F,
        0x20, 0x56, 0x61, 0x75,
        0x6C, 0x74, 0x20, 0x53,
        0x74, 0x75, 0x66, 0x66
    };

    public byte[] Encrypt(byte[] key, byte[] data)
    {
        aes.Start(AESContext.Mode.CbcEncrypt, key, iv);
        byte[] padded = Pad(data, 16);
        byte[] result = aes.Update(padded);
        aes.Finish();
        return result;
    }

    public byte[] Decrypt(byte[] key, byte[] data)
    {
        aes.Start(AESContext.Mode.CbcDecrypt, key, iv);
        byte[] result = aes.Update(data);
        aes.Finish();
        result = UnPad(result);
        return result;
    }
}
