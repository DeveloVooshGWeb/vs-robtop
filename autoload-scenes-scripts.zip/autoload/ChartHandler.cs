using Godot;
using Array = Godot.Collections.Array;
using SysArray = System.Array;
using System.Collections.Generic;
using static Singletons;

public class ChartHandler
{
    public byte[] StringToByteArray(in string str)
    {
        byte[] bytes = new byte[]{ unchecked((byte)str.Length) };
        Utils.Concat(ref bytes, str.ToAscii());
        return bytes;
    }

    public byte[] StringToUInt16Array(in string str)
    {
        ushort strLen = unchecked((ushort)str.Length);
        byte[] bytes = new byte[]{ (byte)(strLen >> 8), (byte)(strLen & 255) };
        Utils.Concat(ref bytes, str.ToAscii());
        return bytes;
    }

    public float TranslateC2P(in Array data)
    {
        if (data[0] is float d0 && data[1] is int d1) return ((d0 * 16f) + (float)d1) * Beat.stepSecs;
        return 0f;
    }

    public Array TranslateP2C(in float secs)
    {
        Array data = new Array(){ 0, (secs / Beat.stepSecs) };
        data[0] = Mathf.FloorToInt((float)data[1] / 16f);
        data[1] = (float)data[1] - ((float)data[0] * 16f);
        return data;
    }

    public NoteData[] NoteDictToNoteArr(in Dictionary<int, NoteData> noteDict)
    {
        NoteData[] noteArr = new NoteData[]{};
        foreach (int key in noteDict.Keys)
        {
            int idx = noteArr.Length;
            SysArray.Resize<NoteData>(ref noteArr, idx + 1);
            noteArr[idx] = noteDict[key];
        }
        SysArray.Sort<NoteData>(noteArr, 0, noteArr.Length, new NoteRowSort());
        return noteArr;
    }

    public Dictionary<int, NoteData> NoteArrToNoteDict(in NoteData[] noteArr)
    {
        Dictionary<int, NoteData> noteDict = new Dictionary<int, NoteData>();
        for (int i = 0; i < noteArr.Length; i++)
        {
            noteDict.Add(noteArr[i].GetHashCode(), noteArr[i]);
        }
        return noteDict;
    }

    public byte[] Conv(in ChartData data)
    {
        int speed = Mathf.FloorToInt(data.speed * 100f);
        byte[] chartData = new byte[]{
            (byte)(data.bpm >> 8), (byte)(data.bpm & 255),
            (byte)(speed >> 8), (byte)(speed & 255)
        };
        Utils.Concat(ref chartData, StringToByteArray(data.song));
        ref SectionData[] sections = ref data.sections;
        int sectionList = sections.Length;
        Utils.Concat(ref chartData, new byte[]{ (byte)(sectionList >> 8), (byte)(sectionList & 255) });
        foreach (SectionData section in sections)
        {
            Utils.Push(ref chartData, (byte)(section.mustHitSection ? 1 : 0));
            ref Dictionary<int, NoteData> notes = ref section.notesDict;
            byte notesSize = (byte)notes.Count;
            Utils.Concat(ref chartData, new byte[]{ (byte)(notesSize >> 8), (byte)(notesSize & 255) });
            foreach (int key in notes.Keys)
            {
                NoteData note = notes[key];
                Utils.Concat(ref chartData, new byte[]{
                    (byte)(note.alt ? 1 : 0),
                    (byte)(note.col * 16),
                    (byte)(note.row * 2),
                    note.noteType,
                    note.noteId
                });
                ushort[] noteOffset = new ushort[]{ unchecked((ushort)(note.noteOffset.x * 100f)), unchecked((ushort)(note.noteOffset.y * 100f)) };
                Utils.Concat(ref chartData, new byte[]{ (byte)(noteOffset[0] >> 8), (byte)(noteOffset[0] & 255), (byte)(noteOffset[1] >> 8), (byte)(noteOffset[1] & 255) });
                ushort noteLength = unchecked((ushort)(note.noteLength * 100f));
                Utils.Concat(ref chartData, new byte[]{ (byte)(noteLength >> 8), (byte)(noteLength & 255) });
                Utils.Concat(ref chartData, StringToUInt16Array(note.evt));
            }
        }
        return chartData;
    }

    public ChartData Parse(byte[] chartData)
    {
        ChartData data = new ChartData();
        if (chartData.Length > 0)
        {
            int idx = 0;
            data.bpm = (ushort)(chartData[idx] << 8 | chartData[idx++]);
            data.speed = (float)(chartData[idx++] << 8 | chartData[idx++]) / 100f;
            int songLen = chartData[idx++];
            data.song = Utils.Subarray(chartData, idx++, idx += songLen).GetStringFromASCII();
            int sectionLen = chartData[idx++] << 8 | chartData[idx++];
            for (int i = 0; i < sectionLen; i++)
            {
                SectionData section = new SectionData(chartData[idx++] > 0);
                int noteCount = chartData[idx++] << 8 | chartData[idx++];
                for (int j = 0; j < noteCount; j++)
                {
                    NoteData note = new NoteData(chartData[idx++] > 0, false, unchecked((byte)(chartData[idx++] / 16)), unchecked((byte)(chartData[idx++] / 2)), chartData[idx++], chartData[idx++], new Vector2(chartData[idx++] << 8 | chartData[idx++], chartData[idx++] << 8 | chartData[idx++]), (float)(chartData[idx++] << 8 | chartData[idx++]) / 100f);
                    int evtLen = chartData[idx++] << 8 | chartData[idx++];
                    note.evt = Utils.Subarray(chartData, idx++, idx += evtLen).GetStringFromASCII();
                    Utils.Push(ref section.notes, note);
                }
                Utils.Push(ref data.sections, section);
            }
        }
        return data;
    }
}
