using Godot;
using System;

public class Singletons : Node
{
    public static DataHandler Data;
    public static InputHandler Inpt;
    public static SaveManager Save;
    public static BeatHandler Beat;
    public static AESManager AES;
    public static AssetManager Assets;
    public static SoundManager Sound;
    public static Utilities Utils;
    public static ChartHandler Chart;
    public static GEVTParser GEVT;
    public static FPSCounter FpsDisplay;
    public static SceneManager Scn;
    public static EaseHandler Ease;
    public static ScenePause Pause;

    public override void _Ready()
    {
        Data = GetNode<DataHandler>("/root/DataHandler");
        Inpt = GetNode<InputHandler>("/root/InputHandler");
        Save = GetNode<SaveManager>("/root/SaveManager");
        Beat = GetNode<BeatHandler>("/root/BeatHandler");
        Assets = GetNode<AssetManager>("/root/AssetManager");
        AES = GetNode<AESManager>("/root/AESManager");
        Sound = GetNode<SoundManager>("/root/SoundManager");
        Utils = new Utilities();
        Chart = new ChartHandler();
        GEVT = new GEVTParser();
        Scn = GetNode<SceneManager>("/root/SceneManager");
        FpsDisplay = GetNode<FPSCounter>("/root/FPSCounter");
        Ease = GetNode<EaseHandler>("/root/EaseHandler");
        Pause = GetNode<ScenePause>("/root/ScenePause");
    }
}
