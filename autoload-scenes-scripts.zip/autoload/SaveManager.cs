using Godot;
using Godot.Collections;
using System;
using System.Reflection;

public class SaveManager : Node
{
    public string savePath = "user://rub.save";
    public SaveData save = new SaveData();

    public Dictionary<string, object> ToDict()
    {
        Dictionary<string, object> dict = new Dictionary<string, object>()
        {
            { "version", save.version },
            { "vault", new Dictionary<string, object>(){
                { "unlocked", save.vault.unlocked },
                { "entered", save.vault.entered }
            }}
        };
        Dictionary<string, object> songsDict = new Dictionary<string, object>();
        foreach (String key in save.songs.Keys)
        {
            SongSD val = save.songs[key];
            songsDict.Add(key, new Dictionary<string, object>(){
                { "completed", val.completed },
                { "scores", val.scores }
            });
        }
        dict.Add("songs", songsDict);
        return dict;
    }

    public void ToSave(in Dictionary dict)
    {
        foreach (FieldInfo prop in typeof(SaveData).GetFields())
        {
            if (!dict.Contains(prop.Name)) return;
        }
        if (dict["version"] is float version)
        {
            if (save.version == version)
            {
                if (dict["vault"] is Dictionary vault)
                {
                    if (vault["unlocked"] is bool unlocked
                        && vault["entered"] is bool entered)
                    {
                        save.vault.unlocked = unlocked;
                        save.vault.entered = entered;
                    }
                }
                if (dict["songs"] is Dictionary songs)
                {
                    foreach (String key in songs.Keys)
                    {
                        if (songs[key] is Dictionary song)
                        {
                            if (song["completed"] is bool completed
                                && song["scores"] is int[] scores)
                            {
                                SongSD nSong = new SongSD(completed, scores);
                                save.songs.Add(key, nSong);
                            }
                        }
                    }
                }
            }
        }
    }

    public void Save()
    {
        File f = new File();
        if (f.OpenCompressed(savePath, File.ModeFlags.Write, File.CompressionMode.Zstd) == Error.Ok)
        {
            f.StoreString(JSON.Print(ToDict()));
            f.Close();
        }
    }

    public void Load()
    {
        File f = new File();
        if (f.OpenCompressed(savePath, File.ModeFlags.Read, File.CompressionMode.Zstd) == Error.Ok)
        {
            JSONParseResult res = JSON.Parse(f.GetAsText());
            f.Close();
            if (res.Error == Error.Ok)
            {
                ToSave((Dictionary)res.Result);
            }
        }
    }

    public override void _Ready()
    {
        Load();
    }
}
