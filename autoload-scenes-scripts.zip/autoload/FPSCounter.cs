using Godot;
using System;

public class FPSCounter : Node2D
{
    public Label FPS; 

    public override void _Ready()
    {
        FPS = GetNode<Label>("FPSCanvas/FPS");
    }

    public override void _Process(float delta)
    {
        FPS.Text = "FPS: " + Engine.GetFramesPerSecond().ToString();
    }
}
