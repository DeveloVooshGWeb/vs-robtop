using Godot;
using System;
using static Singletons;

public class BeatHandler : Node
{
    // Hey Coders! I Have A Funny And Totally Not Rushed Joke :D
    // I Was Originally Gonna Name This BeatStep Handler
    // Before I Finally Named It To BeatHandler
    // But It Was Too Long So Guess What I Was Going To Name It?
    // BSHandler Haha Get It Cause [B, S] BullShit HAHAHAH
    // That Was A Poorly Made Joke D:

    [Signal] public delegate void finished();
    [Signal] public delegate void sectionHit(int Sections);
    [Signal] public delegate void beatHit(int Beats);
    [Signal] public delegate void stepHit(int Steps);

    // Sidenote: I love working for this mod (and it's painful at the same time but yknow... I have to finish what i started)
    
    public int bpm = 130;

    public int sections = 0;
    public int beats = 0;
    public int steps = 0;

    public int prevSections = -1;
    public int prevBeats = -1;
    public int prevSteps = -1;

    public AudioStreamPlayer song;
    public bool songFinished = false;

    public bool playing = false;

    public float sectionSecs = 0f;
    public float beatSecs = 0f;
    public float stepSecs = 0f;

    public float songPos = 0f;
    public bool startedPlaying = false;

    public void SetBpm(int Bpm = 130)
    {
        bpm = Bpm;
        sectionSecs = (60f / bpm) * 4f;
        beatSecs = sectionSecs / 4f;
        stepSecs = beatSecs / 4f;
    }

    public void Init(ref AudioStreamPlayer Song, in int Bpm = 130)
    {
        startedPlaying = false;
        sections = 0;
        beats = 0;
        steps = 0;
        prevSections = -1;
        prevBeats = -1;
        prevSteps = -1;
        songFinished = false;
        song = Song;
        if (song.IsConnected("finished", this, "Finished")) song.Disconnect("finished", this, "Finished");
        song.Connect("finished", this, "Finished");
        songFinished = false;
        SetBpm(Bpm);
    }

    public bool SongValid()
    {
        if (song == null) return false;
        if (song.Stream == null) return false;
        return true;
    }

    public bool SongAbsValid()
    {
        return SongValid() ? song.Playing : false;
    }

    public float GetPosition()
    {
        return songPos;
    }

    public float GetSteps()
    {
        return GetPosition() / stepSecs;
    }

    public float GetBeats()
    {
        return GetPosition() / beatSecs;
    }

    public float GetSections()
    {
        return GetPosition() / sectionSecs;
    }

    public float GetLength()
    {
        if (!SongValid()) return 0f;
        return song.Stream.GetLength();
    }

    public void StartPlaying()
    {
        startedPlaying = true;
    }

    public void StopPlaying()
    {
        startedPlaying = false;
    }

    public void Finished()
    {
        // ABSOLUTELY FOCUS ON THE AUDIO HANDLER OR SOUND.CS AS IT IS REALLY IMPORTANT IN THIS PART
        song = null;
        songFinished = true;
        EmitSignal("finished");
    }

    public override void _Process(float delta)
    {
        if (startedPlaying) songPos += delta;
        if (SongAbsValid())
        {
            float actualPos = song.GetPlaybackPosition();
            if (Mathf.Abs(Mathf.Round(actualPos - songPos)) >= Data.vocalResetThres) songPos = actualPos;
            float songLen = GetLength();
            float songMins = songPos / 60f;
            float stepsF = (float)bpm * songMins * 4f;
            float beatsF = stepsF / 4f;
            float secsF = beatsF / 4f;
            steps = Mathf.FloorToInt(stepsF);
            beats = Mathf.FloorToInt(beatsF);
            sections = Mathf.FloorToInt(secsF);
            if (steps != prevSteps) EmitSignal("stepHit", steps);
            if (beats != prevBeats) EmitSignal("beatHit", beats);
            if (sections != prevSections) EmitSignal("sectionHit", sections);
            prevSteps = steps;
            prevBeats = beats;
            prevSections = sections;
        }
    }
}
