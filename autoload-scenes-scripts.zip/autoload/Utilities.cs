using Godot;
using System;

public class Utilities : Node
{
    public bool Collide(in Vector2 p1, in Vector2 s1, in Vector2 p2, in Vector2 s2)
    {
        Vector2 r1 = new Vector2(s1.x / 2f, s1.y / 2f);
        Vector2 r2 = new Vector2(s2.x / 2f, s2.y / 2f);
        return p1.x + r1.x >= p2.x - r2.x && p1.x - r1.x <= p2.x + r2.x && p1.y + r1.y >= p2.y - r2.y && p1.y - r1.y <= p2.y + r2.y;
    }

    public string snake_case(in string str)
    {
        return str.StripEdges().ToLower().Replace(" ", "_");
    }

    public void Push(ref byte[] a, in byte b)
    {
        int idx = a.Length;
        Array.Resize<byte>(ref a, idx + 1);
        a[idx] = b;
    }

    public void Push(ref NoteData[] a, in NoteData b)
    {
        int idx = a.Length;
        Array.Resize<NoteData>(ref a, idx + 1);
        a[idx] = b;
    }

    public void Push(ref SectionData[] a, in SectionData b)
    {
        int idx = a.Length;
        Array.Resize<SectionData>(ref a, idx + 1);
        a[idx] = b;
    }

    public void Push(ref EventData[] a, in EventData b)
    {
        int idx = a.Length;
        Array.Resize<EventData>(ref a, idx + 1);
        a[idx] = b;
    }

    public void Concat(ref byte[] a, in byte[] b)
    {
        int idx = a.Length;
        int alen = b.Length;
        Array.Resize<byte>(ref a, idx + alen);
        Buffer.BlockCopy(b, 0, a, idx, alen);
    }

    public void Concat(ref NoteData[] a, in NoteData[] b)
    {
        int idx = a.Length;
        int alen = b.Length;
        Array.Resize<NoteData>(ref a, idx + alen);
        Buffer.BlockCopy(b, 0, a, idx, alen);
    }



    public byte[] Subarray(in byte[] a, in int b, in int c)
    {
        byte[] d = new byte[c];
        Buffer.BlockCopy(a, b, d, 0, c);
        return d;
    }
}
