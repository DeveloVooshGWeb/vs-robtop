using Godot;
using System;
using static Singletons;

public class ScenePause : Node2D
{
    public CanvasLayer canvas;
    public Node2D pauseScreen;
    public Label label;

    public string[] labelList;
    public string labelBase = "GAME PAUSED";

    public string easeName = "PauseAlpha";
    public float easeTime = 0.5f;

    public override void _Ready()
    {
        canvas = GetNode<CanvasLayer>("Canvas");
        pauseScreen = canvas.GetNode<Node2D>("PauseScreen");
        label = pauseScreen.GetNode<Label>("Label");
        labelList = Assets.GetText("pauseScreen", false, true).Split("\n\n");
    }

    public void RandomizeLabelText()
    {
        label.Text = labelBase + "\n\n" + labelList[GD.Randi() % labelList.Length];
    }

    public override void _Notification(int what)
    {
        switch (what)
        {
            case MainLoop.NotificationWmFocusOut:
                GetTree().Paused = true;
                Ease.SetEase(easeName, 0f, 1f, easeTime, "Expo", "Out", true);
                Ease.PlayEase(easeName);
                RandomizeLabelText();
                break;
            case MainLoop.NotificationWmFocusIn:
                GetTree().Paused = false;
                Ease.SetV2(easeName, Ease.GetEase(easeName));
                Ease.PlayEase(easeName, true);
                break;
        }
    }
    
    public override void _Process(float delta)
    {
        float alpha = Ease.GetEase(easeName);
        pauseScreen.Modulate = new Color(pauseScreen.Modulate.r, pauseScreen.Modulate.g, pauseScreen.Modulate.b, alpha);
        if (alpha <= 0f)
        {
            canvas.Layer = -128;
            return;
        }
        canvas.Layer = 128;
    }
}
