using Godot;
using System;
using System.Linq;
using System.Reflection;
using static Singletons;

public class SceneManager : Node2D
{
    [Signal] public delegate void finished();
    [Signal] public delegate void changingScene();

    public CanvasLayer canvas;
    public Node2D parent;

    public AnimationPlayer animationPlayer;
    public Label text;
    public Timer timer;

    public string[] loadingTexts;

    public string[] animList = { "fadeIn", "fadeOut" };
    public string defScenePath = "res://scenes/";
    public string sceneExt = "tscn";
    public string scn = "";
    public bool firstTime = false;
    public bool stopListening = false;
    public bool queueStopMusic = false;

    public bool timerStarted = false;
    public float timerSecs = 1f;

    public bool fadedIn = false;

    public SceneTree _tree;
    public Viewport _root;

    public void HideP()
    {   
        parent.Modulate = new Color(parent.Modulate.r, parent.Modulate.g, parent.Modulate.b, 0f);
    }

    public override void _Ready()
    {
        _tree = GetTree();
        _root = _tree.Root;
        canvas = GetNode<CanvasLayer>("Canvas");
        parent = canvas.GetNode<Node2D>("Parent");
        animationPlayer = parent.GetNode<AnimationPlayer>("Anim");
        text = parent.GetNode<Label>("Text");
        timer = parent.GetNode<Timer>("Timer");
        HideP();
        firstTime = true;
        loadingTexts = Assets.GetText("loading", false, true).Split("\n\n");
        timer.Connect("timeout", this, "Timeout");
    }

    public void Init()
    {
        if (firstTime)
        {
            firstTime = false;
            EmitSignal("finished");
        }
    }

    public void PlaceBelow()
    {
        canvas.Layer = -128;
        canvas.Visible = false;
    }

    public void PlaceAbove()
    {
        canvas.Layer = 127;
        canvas.Visible = true;
    }

    public void FadeOut()
    {
        animationPlayer.Play("fadeOut");
    }

    public void FadeIn()
    {
        animationPlayer.Play("fadeIn");
    }

    public void Timeout()
    {
        timerStarted = false;
        FadeOut();
    }

    public void RandomizeText()
    {
        text.Text = loadingTexts[GD.Randi() % loadingTexts.Length];
    }

    public void _Chscn()
    {
        EmitSignal("changingScene");
        _tree.CurrentScene.Free();
        Node scene = ResourceLoader.Load<PackedScene>(scn).Instance();
        _root.AddChild(scene);
        _tree.CurrentScene = scene;
        if (queueStopMusic) Sound.StopAll();
        if (!timerStarted) FadeOut();
        stopListening = false;
    }

    public void Switch(string inputScene, bool stopMusic = false)
    {
        queueStopMusic = stopMusic;
        FpsDisplay.FPS.Visible = true;
        Data.disableInput = false;
        scn = defScenePath + inputScene + "." + sceneExt;
        FadeIn();
    }
    
    public void SwitchAbsolute(string inputScene, bool stopMusic = false)
    {
        queueStopMusic = stopMusic;
        FpsDisplay.FPS.Visible = true;
        Data.disableInput = false;
        scn = inputScene + "." + sceneExt;
        FadeIn();
    }

    public void SwitchWithText(string inputScene, bool stopMusic = false)
    {
        FpsDisplay.FPS.Visible = true;
        RandomizeText();
        timer.Start(timerSecs);
        timerStarted = true;
        Switch(inputScene, stopMusic);
    }

    public override void _Process(float delta)
    {
        if (!stopListening)
        {
            PlaceAbove();
            string animName = animationPlayer.AssignedAnimation;
            if (animName == "")
            {
                PlaceBelow();
                HideP();
                return;
            }
            if (animationPlayer.CurrentAnimationPosition >= 0.4f)
            {
                switch (animName)
                {
                    case "fadeIn":
                        if (!fadedIn)
                        {
                            fadedIn = true;
                            if (scn != null)
                            {
                                stopListening = true;
                                _Chscn();
                            }
                            else if (!timerStarted)
                            {
                                FadeOut();
                            }
                        }
                        break;
                    case "fadeOut":
                        text.Text = "";
                        animationPlayer.Play("RESET");
                        EmitSignal("finished");
                        fadedIn = false;
                        break;
                    default:
                        PlaceBelow();
                        HideP();
                        break;
                }
            }
            else if (!animList.Contains<string>(animName))
            {
                PlaceBelow();
                HideP();
            }
        }
    }
}
