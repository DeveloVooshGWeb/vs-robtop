using Godot;
using System;
using System.Collections.Generic;

public class EaseHandler : Node2D
{
    Dictionary<string, EaseData> easeList = new Dictionary<string, EaseData>();

    public void Clear()
    {
        easeList.Clear();
    }

    public void SetEase(string easeId, float v1 = 0f, float v2 = 0f, float secs = 0f, string transType = "Linear", string easeType = "None", bool unpausable = false)
    {
        EaseData easeData = new EaseData(new Vector3(v1, v2, secs), new Vector2(v2, v1), 0f, v1, transType, easeType, unpausable);
        easeList[easeId] = easeData;
    }

    public void SetV1(string easeId, float v)
    {
        if (!easeList.ContainsKey(easeId)) return;
        easeList[easeId].data.x = v;
        easeList[easeId].current.x = v;
    }

    public void SetV2(string easeId, float v)
    {
        if (!easeList.ContainsKey(easeId)) return;
        easeList[easeId].data.y = v;
        easeList[easeId].current.y = v;
    }

    public float GetEase(string easeId)
    {
        return !easeList.ContainsKey(easeId) ? 0f : easeList[easeId].value;
    }

    public void RestartEase(string easeId)
    {
        if (!easeList.ContainsKey(easeId)) return;
        easeList[easeId].elapsed = 0f;
    }

    public void PauseEase(string easeId)
    {
        easeList[easeId].playing = false;
    }

    public void PlayEase(string easeId, bool invert = false)
    {
        if (!easeList.ContainsKey(easeId)) return;
        Vector2 prevCurrent = easeList[easeId].current;
        if (invert) easeList[easeId].current = new Vector2(easeList[easeId].data.y, easeList[easeId].data.x);
        else easeList[easeId].current = new Vector2(easeList[easeId].data.x, easeList[easeId].data.y);
        if (easeList[easeId].current.x != prevCurrent.x && easeList[easeId].current.y != prevCurrent.y)
        {
            RestartEase(easeId);
            easeList[easeId].playing = true;
        }
    }

    public override void _Process(float delta)
    {
        foreach (string easeId in easeList.Keys)
        {
            EaseData ease = easeList[easeId];
            if (ease.playing && (!GetTree().Paused || (GetTree().Paused && easeList[easeId].unpausable)))
            {
                easeList[easeId].value = ((float)typeof(Easing).GetNestedType(ease.transition).GetMethod(ease.type).Invoke(null, new object[]{ ease.elapsed, 0f, 1f, ease.data.z }) * (ease.current.y - ease.current.x)) + ease.current.x;
                easeList[easeId].elapsed += delta;
                if (easeList[easeId].elapsed > easeList[easeId].data.z)
                {
                    easeList[easeId].elapsed = easeList[easeId].data.z;
                    PauseEase(easeId);
                }
            }
        }
    }
}
