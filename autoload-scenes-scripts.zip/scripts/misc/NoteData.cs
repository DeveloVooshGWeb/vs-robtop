using Godot;

public class NoteData
{
    public bool alt;
    public bool isStrum;
    public byte col;
    public byte row;
    public byte noteType;
    public byte noteId;
    public Vector2 noteOffset;
    public float noteLength;
    public string evt;

    public NoteData(bool a = false, bool i = true, byte c = 0, byte r = 0, byte nt = 0, byte ni = 2, Vector2? no = null, float nl = 0f, string e = "")
    {
        alt = a;
        isStrum = i;
        col = c;
        row = r;
        noteType = nt;
        noteId = ni;
        noteOffset = no ?? Vector2.Zero;
        noteLength = nl;
        evt = e;
    }
}