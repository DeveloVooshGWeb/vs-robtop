using Godot;
using System;

public class MiscNoteData
{
    public Vector2 targetPos;
    public bool holdUpdate;
    public float steps;
    public float time;
    public float speed;

    public MiscNoteData(Vector2? ta = null, bool h = false, float st = 0f, float ti = 0f, float sp = 1f)
    {
        targetPos = ta ?? Vector2.Zero;
        holdUpdate = h;
        steps = st;
        time = ti;
        speed = sp;
    }
}