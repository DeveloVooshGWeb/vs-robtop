using Godot;
using System;

public class PackData
{
    public string pack;
    public Color color;
    public int songs;
    public int diff;

    public PackData(string p, Color c, int s, int d)
    {
        pack = p;
        color = c;
        songs = s;
        diff = d;
    }
}
