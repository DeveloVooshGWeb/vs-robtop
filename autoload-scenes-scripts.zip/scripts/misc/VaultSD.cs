public class VaultSD
{
    public bool unlocked;
    public bool entered;

    public VaultSD(bool u = false, bool e = false)
    {
        unlocked = u;
        entered = e;
    }
}
