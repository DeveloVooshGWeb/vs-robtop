
public class ChartDataPrototype
{
    public ushort bpm;
    public float scrollSpeed;
    public string song;

    public ChartDataPrototype(ushort b = 130, float sc = 1f, string so = "")
    {
        bpm = b;
        scrollSpeed = sc;
        song = so;
    }
}