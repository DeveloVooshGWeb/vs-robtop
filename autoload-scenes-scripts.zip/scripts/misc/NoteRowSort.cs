using System.Collections.Generic;

public class NoteRowSort : IComparer<NoteData>
{
    public int Compare(NoteData x, NoteData y)
    {
        if (x.row == y.row) return 0;
        if (x.row < y.row) return -1;
        return 1;
    }
}