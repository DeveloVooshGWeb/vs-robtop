using Godot.Collections;

public class SaveData
{
    public float version;
    public VaultSD vault;
    public Dictionary<string, SongSD> songs;

    public SaveData(float ver = 1f, VaultSD v = null, Dictionary<string, SongSD> s = null)
    {
        if (v == null) v = new VaultSD();
        if (s == null) s = new Dictionary<string, SongSD>();
        version = ver;
        vault = v;
        songs = s;
    }
}
