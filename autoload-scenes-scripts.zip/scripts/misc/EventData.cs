using Godot.Collections;

public class EventData
{
    public string function;
    public Array args;

    public EventData(string f = "", Array a = null)
    {
        if (a == null) a = new Array();
        function = f;
        args = a;
    }
}