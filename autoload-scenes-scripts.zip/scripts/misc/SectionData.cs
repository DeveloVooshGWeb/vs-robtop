using System.Collections.Generic;

public class SectionData
{
    public bool mustHitSection;
    public NoteData[] notes;
    public Dictionary<int, NoteData> notesDict;

    public SectionData(bool m = true, NoteData[] n = null, Dictionary<int, NoteData> nd = null)
    {
        if (n == null) n = new NoteData[]{};
        if (nd == null) nd = new Dictionary<int, NoteData>();
        mustHitSection = m;
        notes = n;
        notesDict = nd;
    }
}