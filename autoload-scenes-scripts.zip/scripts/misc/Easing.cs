using Godot;

public class Easing
{
    public class Back
    {
        public static float In(float t, float b, float c, float d, float s = 1.70158f)
        {
            t /= d;
            return c * t * t * ((s + 1f) * t - s) + b;
        }
        
        public static float Out(float t, float b, float c, float d, float s = 1.70158f)
        {
            t = t / d - 1f;
            return c * (t * t * ((s + 1) * t + s) + 1f) + b;
        }
        
        public static float InOut(float t, float b, float c, float d, float s = 1.70158f)
        {
            t = t / d * 2f;
            s *= 1.525f;
            if (t < 1) return c / 2f * (t * t * ((s + 1f) * t - s)) + b;
            t -= 2f;
            return c / 2f * (t * t * ((s + 1f) * t + s) + 2f) + b;
        }
        
        public static float OutIn(float t, float b, float c, float d, float s = 1.70158f)
        {
            return t < d / 2f ? Out(t * 2f, b, c / 2f, d, s) : In((t * 2f) - d, b + c / 2f, c / 2f, d, s);
        }
    }

    public class Bounce
    {
        public static float Out(float t, float b, float c, float d)
        {
            t /= d;
            if (t < 1f / 2.75f) return c * (7.5625f * t * t) + b;
            else if (t < 2f / 2.75f)
            {
                t -= 1.5f / 2.75f;
                return c * (7.5625f * t * t + 0.75f) + b;
            }
            else if (t < 2.5f / 2.75f)
            {
                t -= 2.25f / 2.75f;
                return c * (7.5625f * t * t + 0.9375f) + b;
            }
            else
            {
                t -= 2.625f / 2.75f;
                return c * (7.5625f * t * t + 0.984375f) + b;
            }
        }
        
        public static float In(float t, float b, float c, float d)
        {
            return c - Out(d - t, 0f, c, d) + b;
        }

        public static float InOut(float t, float b, float c, float d)
        {
            if (t < d / 2f) return In(t * 2f, 0f, c, d) * 0.5f + b;
            else return Out(t * 2f - d, 0f, c, d) * 0.5f + c * 0.5f + b;
        }
        
        public static float OutIn(float t, float b, float c, float d)
        {
            return t < d / 2f ? Out(t * 2f, b, c / 2f, d) : In((t * 2f) - d, b + c / 2f, c / 2f, d);
        }
    }

    public class Circ
    {
        public static float In(float t, float b, float c, float d)
        {
            t /= d;
            return -c * (Mathf.Sqrt(1f - t * t) - 1f) + b;
        }

        public static float Out(float t, float b, float c, float d)
        {
            t = t / d - 1f;
            return c * Mathf.Sqrt(1f - t * t) + b;
        }

        public static float InOut(float t, float b, float c, float d)
        {
            t = t / d * 2f;
            if (t < 1f) return -c / 2f * (Mathf.Sqrt(1f - t * t) - 1f) + b;
            t -= 2f;
            return c / 2f * (Mathf.Sqrt(1f - t * t) + 1) + b;
        }
        
        public static float OutIn(float t, float b, float c, float d)
        {
            return t < d / 2f ? Out(t * 2f, b, c / 2f, d) : In((t * 2f) - d, b + c / 2f, c / 2f, d);
        }
    }

    public class Elastic
    {
        // a = amplitude; p = period
        public static float In(float t, float b, float c, float d, float a = 0f, float p = 0f)
        {
            if (t == 0f) return b;
            t /= d;
            if (t == 1f) return b + c;
            if (p == 0f) p = d * 0.3f;
            float s;
            if (a == 0f || a < (c < 0f ? -c : c))
            {
                a = c;
                s = p / 4f;
            }
            else
            {
                s = p / (2f * Mathf.Pi) * Mathf.Asin(c / a);
            }
            t -= 1;
            return -(a * Mathf.Pow(2f, 10f * t) * Mathf.Sin((t * d - s) * (2f * Mathf.Pi) / p)) + b;
        }

        public static float Out(float t, float b, float c, float d, float a = 0f, float p = 0f)
        {
            if (t == 0f) return b;
            t /= d;
            if (t == 1f) return b + c;
            if (p == 0f) p = d * 0.3f;
            float s;
            if (a == 0f)
            {
                a = c;
                s = p / 4f;
            }
            else
            {
                s = p / (2f * Mathf.Pi) * Mathf.Asin(c / a);
            }
            return a * Mathf.Pow(2f, -10f * t) * Mathf.Sin((t * d - s) * (2f * Mathf.Pi) / p) + c + b;
        }

        public static float InOut(float t, float b, float c, float d, float a = 0f, float p = 0f)
        {
            if (t == 0f) return b;
            t = t / d * 2f;
            if (t == 2f) return b + c;
            if (p == 0f) p = d * 0.3f * 1.5f;
            float s;
            if (a == 0f || a < (c < 0f ? -c : c))
            {
                a = c;
                s = p / 4f;
            }
            else
            {
                s = p / (2f * Mathf.Pi) * Mathf.Asin(c / a);
            }
            t -= 1;
            if (t < 1f)
            {
                return -0.5f * (a * Mathf.Pow(2f, 10f * t) * Mathf.Sin((t * d - s) * (2f * Mathf.Pi) / p)) + b;
            }
            else
            {
                return a * Mathf.Pow(2f, -10f * t) * Mathf.Sin((t * d - s) * (2f * Mathf.Pi) / p) * 0.5f + c + b;
            }
        }
        
        public static float OutIn(float t, float b, float c, float d, float a = 0f, float p = 0f)
        {
            return t < d / 2f ? Out(t * 2f, b, c / 2f, d, a, p) : In((t * 2f) - d, b + c / 2f, c / 2f, d, a, p);
        }
    }

    public class Expo
    {
        public static float In(float t, float b, float c, float d)
        {
            return t == d ? b : c * Mathf.Pow(2f, 10f * (t / d - 1f)) + b - c * 0.001f;
        }

        public static float Out(float t, float b, float c, float d)
        {
            return t == d ? b + c : c * 1.001f * (-Mathf.Pow(2f, -10f * t / d) + 1f) + b;
        }

        public static float InOut(float t, float b, float c, float d)
        {
            if (t == 0f) return b;
            if (t == d) return b + c;
            t = t / d * 2f;
            if (t < 1f) return c / 2f * Mathf.Pow(2f, 10f * (t - 1f)) + b - c * 0.0005f;
            t -= 1;
            return c / 2f * 1.0005f * (-Mathf.Pow(2f, -10f * t) + 2f) + b;
        }

        public static float OutIn(float t, float b, float c, float d)
        {
            return t < d / 2f ? Out(t * 2f, b, c / 2f, d) : In((t * 2) - d, b + c / 2f, c / 2f, d);
        }
    }

    public class Linear
    {
        public static float None(float t, float b, float c, float d) { return c * t / d + b; }
        public static float In(float t, float b, float c, float d) { return None(t, b, c, d); }
        public static float Out(float t, float b, float c, float d) { return None(t, b, c, d); }
        public static float InOut(float t, float b, float c, float d) { return None(t, b, c, d); }
        public static float OutIn(float t, float b, float c, float d) { return None(t, b, c, d); }
    }
}