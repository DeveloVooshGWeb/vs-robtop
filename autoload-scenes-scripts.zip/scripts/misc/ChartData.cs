
public class ChartData
{
    public ushort bpm;
    public float speed;
    public string song;
    public SectionData[] sections;

    public ChartData(ushort b = 130, float sp = 1f, string so = "", SectionData[] se = null)
    {
        if (se == null) se = new SectionData[]{};
        bpm = b;
        speed = sp;
        song = so;
        sections = se;
    }
}