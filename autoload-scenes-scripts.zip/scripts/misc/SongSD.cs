using Godot;
using System;

public class SongSD
{
    public bool completed;
    public int[] scores = { 0, 0, 0 };

    public SongSD(bool c = false, int[] s = null)
    {
        if (s == null) s = new int[]{};
        completed = c;
        if (s.Length == 3) scores = s;
    }
}