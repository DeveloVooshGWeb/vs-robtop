public class DelimiterProperties
{
    public string delimiter = "";
    public byte flag = 0;
}