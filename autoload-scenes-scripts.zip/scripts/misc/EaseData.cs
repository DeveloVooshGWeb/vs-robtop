using Godot;

public class EaseData
{
    public Vector3 data;
    public Vector2 current;
    public float elapsed;
    public float value;
    public string transition;
    public string type;
    public bool unpausable;
    public bool playing;

    public EaseData(Vector3? d = null, Vector2? c = null, float e = 0f, float v = 0f, string tr = "Linear", string ty = "None", bool u = false, bool p = false)
    {
        data = d ?? Vector3.Zero;
        current = c ?? Vector2.Zero;
        elapsed = e;
        value = v;
        transition = tr;
        type = ty;
        unpausable = u;
        playing = p;
    }
}