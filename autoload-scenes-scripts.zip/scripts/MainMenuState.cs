using Godot;
using System;
using System.Linq;
using static Singletons;

public class MainMenuState : Node2D
{
    public Camera2D cam;
    public CanvasLayer camCanvas;
    public ColorRect shaderRect;
    public Tween shaderTween;
    
    public float shaderOffset = 2f;
    public string mouseSelected = "";
    public string[] buttonList = {
        "PlayBtn",
        "BonusSongsBtn",
        "StatsBtn",
        "OptsBtn",
        "CreditsBtn"
    };

    public AudioStreamPlayer menuSong;

    public override void _Ready()
    {
        cam = GetNode<Camera2D>("Cam");
        camCanvas = cam.GetNode<CanvasLayer>("CanvasLayer");
        shaderRect = camCanvas.GetNode<ColorRect>("ShaderRect");
        shaderTween = GetNode<Tween>("ShaderTween");
        Ease.Clear();
        foreach (string btn in buttonList) Ease.SetEase(btn, 0.6f, 0.75f, 0.3f, "Bounce", "Out");
        Inpt.Connect("mouseDown", this, "_OnPressed");
        Inpt.Connect("mouseDrag", this, "_OnDrag");
        Inpt.Connect("mouseUp", this, "_OnReleased");
        Beat.Connect("beatHit", this, "BeatHit");
        if (WeakRef(Beat.song).GetRef() == null)
        {
            menuSong = Sound.PlayMusic("rub", "menu", 0.5f, true, "My secret key!!!".ToAscii());
            Beat.Init(ref menuSong, 128);
        }
        else
        {
            menuSong = Beat.song;
        }
        Beat.StartPlaying();
    }

    public void BeatHit(int beats)
    {
        shaderTween.RemoveAll();
        ((ShaderMaterial)shaderRect.Material).SetShaderParam("offset", shaderOffset);
        shaderTween.InterpolateProperty((ShaderMaterial)shaderRect.Material, "shader_param/offset", shaderOffset, 0f, 0.5f);
        shaderTween.Start();
    }

    public void _OnPressed(int idx, Vector2 pos)
    {
        if (idx == 1)
        {
            foreach (string btn in buttonList)
            {
                Sprite btnNode = GetNode<Sprite>(btn);
                if (Utils.Collide(pos, Vector2.Zero, btnNode.Position, btnNode.Texture.GetSize() * btnNode.Transform.Scale)) mouseSelected = btn;
            }
        }
    }

    public void _OnDrag(int idx, Vector2 pos)
    {
        if (idx == 1)
        {
            foreach (string btn in buttonList)
            {
                if (mouseSelected != "")
                {
                    Sprite btnNode = GetNode<Sprite>(btn);
                    if (Utils.Collide(pos, Vector2.Zero, btnNode.Position, btnNode.Texture.GetSize() * btnNode.Transform.Scale))
                    {
                        mouseSelected = btn;
                        Ease.PlayEase(btn);
                    }
                    else
                    {
                        Ease.PlayEase(btn, true);
                    }
                }
            }
        }
    }

    public void _OnReleased(int idx, Vector2 pos)
    {
        if (idx == 1) foreach (string btn in buttonList) Ease.PlayEase(btn, true);
        if (buttonList.Contains<string>(mouseSelected))
        {
            int selected = Array.IndexOf<string>(buttonList, mouseSelected);
            switch (selected)
            {
                case 0:
                    GD.Print("Go To Story Menu");
                    break;
                case 1:
                    GD.Print("Show The Bonus Songs");
                    Scn.Switch("PackState");
                    break;
                case 2:
                    GD.Print("Show The Player Stats");
                    break;
                case 3:
                    GD.Print("Go To The Options");
                    break;
                case 4:
                    GD.Print("Roll The Credits");
                    break;
                default:
                    GD.Print("Invalid Selection!");
                    break;
            }
        }
        mouseSelected = "";
    }

    public override void _Process(float delta)
    {
        foreach (string btn in buttonList)
        {
            Sprite btnNode = GetNode<Sprite>(btn);
            float daScale = Ease.GetEase(btn);
            btnNode.Scale = new Vector2(daScale, daScale);
        }
    }
}