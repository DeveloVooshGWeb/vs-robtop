using Godot;
using System;
using System.Linq;
using static Singletons;

public class TitleState : Node2D
{
    public string[] acceptKeys = { "Enter", "Space" };
    public bool[] initialized = { false, false };
    public bool isLeft = false;

    public AnimatedSprite charDanceTitle;
    public AnimatedSprite logoBumpin;
    public AnimatedSprite titleEnter;
    public Timer enterTimer;

    public bool switching = false;

    public AudioStreamPlayer menuSong;

    public override void _Ready()
    {
        charDanceTitle = GetNode<AnimatedSprite>("CharCanvas/Char/charDanceTitle/AnimatedSprite");
        logoBumpin = GetNode<AnimatedSprite>("LogoCanvas/Logo/logoBumpin/AnimatedSprite");
        titleEnter = GetNode<AnimatedSprite>("TitleEnter");
        enterTimer = GetNode<Timer>("EnterTimer");
        charDanceTitle.Frames = Assets.GetSpriteFrames("title/chars/2");
        charDanceTitle.Play("danceLeft");
        logoBumpin.Play("default");
        enterTimer.Connect("timeout", this, "_Switch");
        initialized[0] = true;
        Scn.Connect("finished", this, "_SceneLoaded");
        Scn.Init();
    }

    public void _SceneLoaded()
    {
        Scn.Disconnect("finished", this, "_SceneLoaded");
        Beat.Connect("beatHit", this, "BeatHit");
        menuSong = Sound.PlayMusic("rub", "menu", 0.5f, true, "My secret key!!!".ToAscii());
        Beat.Init(ref menuSong, 128);
        Beat.StartPlaying();
        initialized[1] = true;
        Inpt.Connect("justPressed", this, "JustPressed");
    }

    public void BeatHit(int curBeat)
    {
        if (!initialized.Contains<bool>(false))
        {
            if (isLeft) charDanceTitle.Play("danceLeft");
            else charDanceTitle.Play("danceRight");
            isLeft = !isLeft;
            charDanceTitle.Frame = 0;
            logoBumpin.Frame = 0;
        }
    }

    public void _Switch()
    {
        Scn.SwitchWithText("MainMenuState");
    }

    public void JustPressed(string key)
    {
        if (!initialized.Contains<bool>(false) && !switching && acceptKeys.Contains<string>(key))
        {
            switching = true;
            Sound.Play("confirmMenu");
            titleEnter.Play("pressed");
            enterTimer.Start(1f);
        }
    }
}